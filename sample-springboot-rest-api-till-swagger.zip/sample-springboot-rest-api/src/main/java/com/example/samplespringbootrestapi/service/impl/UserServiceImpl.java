package com.example.samplespringbootrestapi.service.impl;

import com.example.samplespringbootrestapi.dto.UserDto;
import com.example.samplespringbootrestapi.entity.User;
import com.example.samplespringbootrestapi.exception.EmailAlreadyExistsException;
import com.example.samplespringbootrestapi.exception.ResourceNotFoundException;
import com.example.samplespringbootrestapi.repository.UserRepository;
import com.example.samplespringbootrestapi.service.UserService;
import lombok.AllArgsConstructor;
import com.example.samplespringbootrestapi.mapper.UserMapper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private ModelMapper modelMapper;

    @Override
    public UserDto createUser(UserDto userDto) {
        //convert dto to entity
//        User user = UserMapper.mapToUser(userDto);
        User user = modelMapper.map(userDto, User.class);

        Optional<User> optionalUser = userRepository.findByEmail(user.getEmail());

        if (optionalUser.isPresent()){
            throw new EmailAlreadyExistsException("Email Already Exists");
        }

        User createdUser = userRepository.save(user);
        //convert entity to dto
//        UserDto createUserDto = UserMapper.mapToUserDto(user);
        UserDto createUserDto = modelMapper.map(user, UserDto.class);
        return createUserDto;
    }

    @Override
    public UserDto getUserById(Long userId) {
        User user = userRepository.findById(userId).
                orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        return UserMapper.mapToUserDto(user);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        List<UserDto> userDtos = users.stream()
                .map(user -> modelMapper.map(user, UserDto.class)).collect(Collectors.toList());
        return userDtos;
    }

    @Override
    public UserDto updateUser(UserDto userDto) {

//        User user = UserMapper.mapToUser(userDto);
        User user = modelMapper.map(userDto, User.class);

        User existingUser = userRepository.findById(user.getId()).
                orElseThrow(() -> new ResourceNotFoundException("User", "id", user.getId()));

        existingUser.setEmail(user.getEmail());
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());

        User updatedUser = userRepository.save(existingUser);

//        UserDto updatedUserDto = UserMapper.mapToUserDto(updatedUser);
        UserDto updatedUserDto = modelMapper.map(updatedUser, UserDto.class);

        return updatedUserDto;
    }

    @Override
    public void deleteUser(Long userId) {
        User existingUser = userRepository.findById(userId).
                orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        userRepository.deleteById(existingUser.getId());
    }
}
