package com.example.samplespringbootrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSpringbootRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
