package com.example.todo.management.service;

import com.example.todo.management.entity.User;
import com.example.todo.management.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class JwtTokenFilter extends OncePerRequestFilter { // filter 1 -> filter 2 -> controller

    private JwtUtil jwtUtil;
    private UserRepository userRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        //Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlzcyI6Imd1dmkuY29tIiwiaWF0IjoxNjk5MzI2NDY0LCJleHAiOjE2OTkzMjY3NjV9.rnTzdwR3vx1XyqIzSXVNxX2pyhBBFvAZ7Z_Rwi0F_GE
        String authorizationHeader = request.getHeader("Authorization");

        if (authorizationHeader == null || authorizationHeader.isEmpty()
                || !authorizationHeader.startsWith("Bearer")) {
            filterChain.doFilter(request, response);//filtering out the request
            return;
        }

        String token = authorizationHeader.split(" ")[1];
        if (!jwtUtil.validate(token)) {
            filterChain.doFilter(request, response);
            return;
        }


        String username = jwtUtil.getUserName(token);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not exists with this username or email"));

        Set<GrantedAuthority> authorities = user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority(role.getName()))
                .collect(Collectors.toSet()); //roles -> GrantedAuthority

        UsernamePasswordAuthenticationToken _token =
                new UsernamePasswordAuthenticationToken(username, user.getPassword(), authorities);
        _token.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

        // header -> token is valid -> role based authentication -> request -> security context

        SecurityContextHolder.getContext().setAuthentication(_token);

        filterChain.doFilter(request, response);
    }
}
