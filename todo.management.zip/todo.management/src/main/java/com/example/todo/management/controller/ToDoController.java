package com.example.todo.management.controller;

import com.example.todo.management.dto.ToDoDto;
import com.example.todo.management.service.ToDoService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/todos")
public class ToDoController {
    private ToDoService toDoService;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<ToDoDto> addToDo(@RequestBody ToDoDto toDoDto) {
        ToDoDto savedToDo = toDoService.addToDo(toDoDto);
        return new ResponseEntity<>(savedToDo, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<ToDoDto> getToDo(@PathVariable Long id) {
        ToDoDto savedToDo = toDoService.getToDo(id);
        return new ResponseEntity<>(savedToDo, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<ToDoDto>> getAllToDos() {
        List<ToDoDto> toDoDtos = toDoService.getAllToDos();
        return new ResponseEntity<>(toDoDtos, HttpStatus.OK);
    }


    @PutMapping("{id}")
    public ResponseEntity<ToDoDto> updateToDo(@RequestBody ToDoDto toDoDto, @PathVariable Long id) {
        ToDoDto updateToDo = toDoService.updateToDo(toDoDto, id);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }


    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteToDo(@PathVariable Long id) {
        toDoService.deleteToDo(id);
        return new ResponseEntity<>("ToDo deleted", HttpStatus.NO_CONTENT);
    }


    @PatchMapping("{id}/complete")
    public ResponseEntity<ToDoDto> completeToDo(@PathVariable Long id) {
        ToDoDto updateToDo = toDoService.completeToDo(id);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }

    @PatchMapping("{id}/in-complete")
    public ResponseEntity<ToDoDto> incompleteToDo(@PathVariable Long id) {
        ToDoDto updateToDo = toDoService.incompleteToDo(id);
        return new ResponseEntity<>(updateToDo, HttpStatus.OK);
    }


}
