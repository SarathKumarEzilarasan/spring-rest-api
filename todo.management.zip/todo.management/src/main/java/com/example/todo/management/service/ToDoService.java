package com.example.todo.management.service;

import com.example.todo.management.dto.ToDoDto;

import java.util.List;

public interface ToDoService {
    ToDoDto addToDo(ToDoDto toDoDto);
    ToDoDto getToDo(Long id);
    List<ToDoDto> getAllToDos();
    ToDoDto updateToDo(ToDoDto toDoDto,Long id);
    void deleteToDo(Long id);
    ToDoDto completeToDo(Long id);
    ToDoDto incompleteToDo(Long id);
}
