package com.example.todo.management.service.impl;

import com.example.todo.management.dto.ToDoDto;
import com.example.todo.management.entity.ToDo;
import com.example.todo.management.exception.ResourceNotFoundException;
import com.example.todo.management.repository.ToDoRepository;
import com.example.todo.management.service.ToDoService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ToDoServiceImpl implements ToDoService {

    private ToDoRepository toDoRepository;
    private ModelMapper modelMapper;

    @Override
    public ToDoDto addToDo(ToDoDto toDoDto) {
        ToDo toDo = modelMapper.map(toDoDto, ToDo.class);
        ToDo createdToDo = toDoRepository.save(toDo);
        return modelMapper.map(createdToDo, ToDoDto.class);
    }

    @Override
    public ToDoDto getToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ToDo not found with id:" + id));
        return modelMapper.map(toDo, ToDoDto.class);
    }

    @Override
    public List<ToDoDto> getAllToDos() {
        List<ToDo> toDos = toDoRepository.findAll();
        List<ToDoDto> toDoDtos = toDos.stream()
                .map((toDo) -> modelMapper.map(toDo, ToDoDto.class)).collect(Collectors.toList());
        return toDoDtos;
    }

    @Override
    public ToDoDto updateToDo(ToDoDto toDoDto, Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ToDo not found with id:" + id));
        toDo.setTitle(toDoDto.getTitle());
        toDo.setDescription(toDoDto.getDescription());
        toDo.setCompleted(toDoDto.isCompleted());

        ToDo updatedToDo = toDoRepository.save(toDo);
        return modelMapper.map(updatedToDo, ToDoDto.class);
    }

    @Override
    public void deleteToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ToDo not found with id:" + id));
        toDoRepository.delete(toDo);
    }

    @Override
    public ToDoDto completeToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ToDo not found with id:" + id));
        toDo.setCompleted(true);
        ToDo updatedToDo = toDoRepository.save(toDo);
        return modelMapper.map(updatedToDo, ToDoDto.class);
    }

    @Override
    public ToDoDto incompleteToDo(Long id) {
        ToDo toDo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ToDo not found with id:" + id));
        toDo.setCompleted(false);
        ToDo updatedToDo = toDoRepository.save(toDo);
        return modelMapper.map(updatedToDo, ToDoDto.class);
    }
}
